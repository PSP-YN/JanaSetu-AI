# JanaSetu AI — submission handoff

Prepared: 12 November 2026

## Folder

`/home/psp/projects/JanaSetu-AI/submission/`

## Submission files

- `README.md` — package index and links
- `01-product-overview.md` — product, users, differentiation and impact measurement plan
- `02-technical-architecture.md` — architecture, data boundaries and automation constraints
- `03-validation-evidence.md` — test and infrastructure evidence
- `04-demo-script.md` — three-minute synthetic-data demonstration
- `05-release-and-compliance.md` — capability matrix and external approval gates
- `06-submission-checklist.md` — judge Q&A and final checklist
- `07-black-box-ui-report.md` — live UI acceptance findings and corrections
- `JanaSetu_AI_Submission_Deck.pptx` — editable eight-slide deck
- `JanaSetu_AI_Submission_Deck.pdf` — eight-slide PDF export
- `assets/` — six desktop/mobile UI screenshots from the local production build
- `build_submission_deck.py` — reproducible deck source
- `JanaSetu_AI_Submission_Pack.zip` — compressed handoff package

## Verified code and UI

- Repository: https://github.com/PSP-YN/JanaSetu-AI
- PR: https://github.com/PSP-YN/JanaSetu-AI/pull/22
- Branch head: `ca9943760a64101da08cc5d048aa81bdfe448850`
- Latest verified preview: https://janasetu-6r56lvi89-pspyn.vercel.app
- Preview commit: `e66314cd2be48d045e4bac10bd23cd61a6cb3d31`
- Black-box run: https://agent.tinyfish.ai/runs/a4a89586-d618-464d-bbee-3f04c2e9795c
- GitHub Actions CI: https://github.com/PSP-YN/JanaSetu-AI/actions/runs/43091881538
- Local verification: 131/131 unit tests, 49/49 Playwright tests, TypeScript and production build passed.

## Release status — not production released

The latest preview is a Preview deployment, not Production. PR #22 has not been merged. GitHub required checks currently block merge because the Vercel deployment check failed at the team's 100-deployments/day limit and the required Vercel Preview Comments check has not been generated. The full JanaSetu CI workflow passed. No branch-protection checks were bypassed.

The local-first public-beta workflow is demonstrated. Cloud citizen sync, cloud document upload/retrieval, malware scanning and government submission remain disabled. Supabase currently has zero legally approved consent-policy versions, zero independently approved/published scheme versions, zero scanner identities, zero reviewer role assignments and zero deployed Edge Functions. No government API/department authorizations have been obtained. Do not claim legal certification, government approval or official eligibility.

## Local working-tree items preserved

The pre-existing `.gitignore` edit and an uncommitted `services/document-scanner/Dockerfile` change were left untouched. They are not included in PR #22's current head.

## File synchronization note

The Markdown submission documents are committed to the GitHub PR branch. The editable PPTX, PDF export, screenshots, deck source and ZIP archive were generated in the laptop's submission folder after the last GitHub commit; these binary/local handoff assets are not pushed to GitHub yet. The existing Vercel rate-limit and protected-branch checks remain unchanged.
